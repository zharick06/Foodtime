const inputPass = document.getElementById("id_password")

inputPass.setAttribute("placeholder","Password")

const inputUser = document.getElementById("id_username")

inputUser.setAttribute("placeholder","Username")
