const labels = document.querySelectorAll('label')
labels.forEach(element => {
    console.log(element);
    element.remove()
});

console.log(Actualmente);
